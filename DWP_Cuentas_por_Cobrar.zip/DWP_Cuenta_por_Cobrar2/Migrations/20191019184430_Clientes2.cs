﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DWP_Cuenta_por_Cobrar2.Migrations
{
    public partial class Clientes2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Crédito",
                table: "Clientes",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<int>(
                name: "Días_Limite",
                table: "Clientes",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Crédito",
                table: "Clientes");

            migrationBuilder.DropColumn(
                name: "Días_Limite",
                table: "Clientes");
        }
    }
}
