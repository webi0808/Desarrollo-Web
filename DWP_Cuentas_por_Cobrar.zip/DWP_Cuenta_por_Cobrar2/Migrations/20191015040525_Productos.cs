﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DWP_Cuenta_por_Cobrar2.Migrations
{
    public partial class Productos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Franquiciadores_FranquiciadoresId",
                table: "Productos");

            migrationBuilder.AlterColumn<int>(
                name: "FranquiciadoresId",
                table: "Productos",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MarcasId",
                table: "Productos",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Tipos_ProductosId",
                table: "Productos",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Productos_MarcasId",
                table: "Productos",
                column: "MarcasId");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_Tipos_ProductosId",
                table: "Productos",
                column: "Tipos_ProductosId");

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Franquiciadores_FranquiciadoresId",
                table: "Productos",
                column: "FranquiciadoresId",
                principalTable: "Franquiciadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Marcas_MarcasId",
                table: "Productos",
                column: "MarcasId",
                principalTable: "Marcas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Tipos_Productos_Tipos_ProductosId",
                table: "Productos",
                column: "Tipos_ProductosId",
                principalTable: "Tipos_Productos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Franquiciadores_FranquiciadoresId",
                table: "Productos");

            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Marcas_MarcasId",
                table: "Productos");

            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Tipos_Productos_Tipos_ProductosId",
                table: "Productos");

            migrationBuilder.DropIndex(
                name: "IX_Productos_MarcasId",
                table: "Productos");

            migrationBuilder.DropIndex(
                name: "IX_Productos_Tipos_ProductosId",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "MarcasId",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "Tipos_ProductosId",
                table: "Productos");

            migrationBuilder.AlterColumn<int>(
                name: "FranquiciadoresId",
                table: "Productos",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Franquiciadores_FranquiciadoresId",
                table: "Productos",
                column: "FranquiciadoresId",
                principalTable: "Franquiciadores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
