﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DWP_Cuenta_por_Cobrar2.Models.Data.DDL;

namespace DWP_Cuenta_por_Cobrar2.Data
{
    public class CobrosContext : DbContext
    {
        public CobrosContext(DbContextOptions<CobrosContext> options) 
            : base(options)
        {

        }

        public DbSet<DWP_Cuenta_por_Cobrar2.Models.Data.DDL.Clientes> Clientes { get; set; }
        public DbSet<DWP_Cuenta_por_Cobrar2.Models.Data.DDL.Productos> Productos { get; set; }
        public DbSet<DWP_Cuenta_por_Cobrar2.Models.Data.DDL.Marcas> Marcas { get; set; }
        public DbSet<DWP_Cuenta_por_Cobrar2.Models.Data.DDL.Franquiciadores> Franquiciadores { get; set; }
        public DbSet<DWP_Cuenta_por_Cobrar2.Models.Data.DDL.Tipos_Productos> Tipos_Productos { get; set; }
    }
}
