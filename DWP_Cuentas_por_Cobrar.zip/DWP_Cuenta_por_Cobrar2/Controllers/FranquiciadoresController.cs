﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DWP_Cuenta_por_Cobrar2.Data;
using DWP_Cuenta_por_Cobrar2.Models;
using DWP_Cuenta_por_Cobrar2.Models.Data.DDL;

namespace DWP_Cuenta_por_Cobrar2.Controllers
{
    public class FranquiciadoresController : Controller
    {
        private readonly CobrosContext _context;

        public FranquiciadoresController(CobrosContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Franquiciadores.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var franquiciador = await _context.Franquiciadores
                .FirstOrDefaultAsync(m => m.Id == id);

            if (franquiciador == null)
            {
                return NotFound();
            }

            return View(franquiciador);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Descripcion")]Franquiciadores franquiciador)
        {
            if (ModelState.IsValid)
            {
                _context.Add(franquiciador);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(franquiciador);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var franquiciador = await _context.Franquiciadores.FindAsync(id);

            if (franquiciador == null)
            {
                return NotFound();
            }

            return View(franquiciador);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descripcion")]Franquiciadores franquiciador)
        {
            if (id != franquiciador.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(franquiciador);
                    await _context.SaveChangesAsync();
                }

                catch
                {
                    if (!FranquiciadorExists(franquiciador.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(franquiciador);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var franquiciador = await _context.Franquiciadores
                .FirstOrDefaultAsync(m => m.Id == id);

            if (franquiciador == null)
            {
                return NotFound();
            }

            return View(franquiciador);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var franquiciador = await _context.Franquiciadores.FindAsync(id);
            _context.Franquiciadores.Remove(franquiciador);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FranquiciadorExists(int id)
        {
            return _context.Franquiciadores.Any(e => e.Id == id);
        }
    }
}