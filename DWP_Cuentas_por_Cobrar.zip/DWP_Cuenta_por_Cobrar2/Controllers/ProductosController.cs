﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DWP_Cuenta_por_Cobrar2.Data;
using DWP_Cuenta_por_Cobrar2.Models;
using DWP_Cuenta_por_Cobrar2.Models.Data.DDL;

namespace DWP_Cuenta_por_Cobrar2.Controllers
{
    public class ProductosController : Controller
    {
        private readonly CobrosContext _context;

        public ProductosController(CobrosContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var finanzasContext = _context.Productos
                .Include(v => v.Franquiciadores)
                .Include(v => v.Marcas)
                .Include(v => v.Tipos_Productos);

            return View(await finanzasContext.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var producto = await _context.Productos
                .Include(v => v.Franquiciadores)
                .Include(v => v.Marcas)
                .Include(v => v.Tipos_Productos)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (producto == null)
            {
                return NotFound();
            }

            return View(producto);
        }

        public IActionResult Create()
        {
            ViewData["FranquiciadoresId"] = new SelectList(_context.Set<Franquiciadores>(), "Id", "Descripcion");
            ViewData["MarcasId"] = new SelectList(_context.Set<Marcas>(), "Id", "Descripcion");
            ViewData["Tipos_ProductosId"] = new SelectList(_context.Set<Tipos_Productos>(), "Id", "Descripcion");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Descripcion,Presentacion,FranquiciadoresId,MarcasId,Tipos_ProductosId")]Productos producto)
        {
            if (ModelState.IsValid)
            {
                _context.Add(producto);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["FranquiciadoresId"] = new SelectList(_context.Set<Franquiciadores>(), "Id", "Descripcion");
            ViewData["MarcasId"] = new SelectList(_context.Set<Marcas>(), "Id", "Descripcion");
            ViewData["Tipos_ProductosId"] = new SelectList(_context.Set<Tipos_Productos>(), "Id", "Descripcion");
            return View(producto);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            ViewData["FranquiciadoresId"] = new SelectList(_context.Set<Franquiciadores>(), "Id", "Descripcion");
            ViewData["MarcasId"] = new SelectList(_context.Set<Marcas>(), "Id", "Descripcion");
            ViewData["Tipos_ProductosId"] = new SelectList(_context.Set<Tipos_Productos>(), "Id", "Descripcion");
            var producto = await _context.Productos.FindAsync(id);

            if (producto == null)
            {
                return NotFound();
            }

            return View(producto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descripcion,Presentacion,FranquiciadoresId,MarcasId,Tipos_ProductosId")]Productos producto)
        {
            if (id != producto.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(producto);
                    await _context.SaveChangesAsync();
                }

                catch
                {
                    if (!ProductoExists(producto.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            ViewData["FranquiciadoresId"] = new SelectList(_context.Set<Franquiciadores>(), "Id", "Descripcion");
            ViewData["MarcasId"] = new SelectList(_context.Set<Marcas>(), "Id", "Descripcion");
            ViewData["Tipos_ProductosId"] = new SelectList(_context.Set<Tipos_Productos>(), "Id", "Descripcion");
            return View(producto);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var producto = await _context.Productos
                .Include(v => v.Franquiciadores)
                .Include(v => v.Marcas)
                .Include(v => v.Tipos_Productos)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (producto == null)
            {
                return NotFound();
            }

            return View(producto);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            _context.Productos.Remove(producto);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductoExists(int id)
        {
            return _context.Productos.Any(e => e.Id == id);
        }

    }
}