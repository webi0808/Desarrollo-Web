﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DWP_Cuenta_por_Cobrar2.Data;
using DWP_Cuenta_por_Cobrar2.Models;
using DWP_Cuenta_por_Cobrar2.Models.Data.DDL;

namespace DWP_Cuenta_por_Cobrar2.Controllers
{
    public class Tipos_ProductosController : Controller
    {
        private readonly CobrosContext _context;

        public Tipos_ProductosController(CobrosContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Tipos_Productos.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tipo_producto = await _context.Tipos_Productos
                .FirstOrDefaultAsync(m => m.Id == id);

            if (tipo_producto == null)
            {
                return NotFound();
            }

            return View(tipo_producto);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Descripcion")]Tipos_Productos tipos_producto)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tipos_producto);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(tipos_producto);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tipo_producto = await _context.Tipos_Productos.FindAsync(id);

            if (tipo_producto == null)
            {
                return NotFound();
            }

            return View(tipo_producto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descripcion")]Tipos_Productos tipo_producto)
        {
            if (id != tipo_producto.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tipo_producto);
                    await _context.SaveChangesAsync();
                }

                catch
                {
                    if (!Tipo_ProductoExists(tipo_producto.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(tipo_producto);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tipo_producto = await _context.Tipos_Productos
                .FirstOrDefaultAsync(m => m.Id == id);

            if (tipo_producto == null)
            {
                return NotFound();
            }

            return View(tipo_producto);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tipo_producto = await _context.Tipos_Productos.FindAsync(id);
            _context.Tipos_Productos.Remove(tipo_producto);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool Tipo_ProductoExists(int id)
        {
            return _context.Tipos_Productos.Any(e => e.Id == id);
        }
    }
}