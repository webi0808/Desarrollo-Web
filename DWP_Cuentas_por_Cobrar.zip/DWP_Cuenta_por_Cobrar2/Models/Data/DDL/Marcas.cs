﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DWP_Cuenta_por_Cobrar2.Models.Data.DDL
{
    public class Marcas
    {
        public int Id { get; set; }

        [Required]
        public string Descripcion { get; set; }

        public ICollection<Productos> Productos { get; set; }
    }
}
