﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DWP_Cuenta_por_Cobrar2.Models.Data.DDL
{
    public class Clientes
    {
        public int Id { get; set; }

        [Required]
        public string Nombres { get; set; }

        [Required]
        public string Apellidos { get; set; }

        [Required]
        public string Direccion { get; set; }

        [Required]
        public string NIT { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public double Crédito { get; set; }

        [Required]
        public int Días_Limite { get; set; }
    }
}
