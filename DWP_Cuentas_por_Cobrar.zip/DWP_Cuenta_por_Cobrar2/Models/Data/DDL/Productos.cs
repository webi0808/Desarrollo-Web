﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DWP_Cuenta_por_Cobrar2.Models.Data.DDL
{
    public class Productos
    {
        public int Id { get; set; }

        [Required]
        public string Descripcion { get; set; }

        [Required]
        public string Presentacion { get; set; }

        [Required]
        [ForeignKey("Marcas")]
        public int MarcasId { get; set; }
        public Marcas Marcas { get; set; }

        [Required]
        [ForeignKey("Franquiciadores")]
        public int FranquiciadoresId { get; set; } 
        public Franquiciadores Franquiciadores { get; set; }

        [Required]
        [ForeignKey("Tipos_Productos")]
        public int Tipos_ProductosId { get; set; }
        public Tipos_Productos Tipos_Productos { get; set; }
    }
}
